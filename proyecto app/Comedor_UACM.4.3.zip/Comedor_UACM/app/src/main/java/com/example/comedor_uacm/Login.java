package com.example.comedor_uacm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    private EditText email;
    private EditText password;
    Button btnIn,btnReg;

    Button btnPR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = (EditText)findViewById(R.id.inEmail);
        password = (EditText)findViewById(R.id.inPassword);
        TextView email =(TextView) findViewById(R.id.inEmail);
        TextView password =(TextView) findViewById(R.id.inPassword);

        btnIn=(Button)findViewById(R.id.button_login);
        btnIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().equals("admin") && password.getText().toString().equals("1234")){
                    Toast.makeText(Login.this, "LOGIN CORRECTO", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent (Login.this, menu_gestion_encargado.class);
                    startActivity(i);
                }else
                    Toast.makeText(Login.this, "LOGIN INCORRECTO", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
