package com.example.comedor_uacm;

import adapter.RecyclerAdapter1;

public interface RecyclerViewInterface {
    void onItemClick(int position);

}
