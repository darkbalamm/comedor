package com.example.comedor_uacm;

public interface RecyclerViewInterface {
    void onItemClick(int position);

}
